import React from 'react'
import { useGetTodos } from "../service/query/useGetTodos"
import useDebounce from "../hook/useDebounce";
import { Card } from "../components/card";
import Skeleton from "react-loading-skeleton";

export const Search = () => {
    const [input, setInput] = React.useState('')
    const value = useDebounce(input)
    const { data, isLoading } = useGetTodos(value);
    console.log(data);
    return (
        <div className="container mt-5 mx-auto">
            <input className="w-[800px] mx-auto rounded-lg p-1 mb-10 pl-4 outline-none border-2 border-black" onChange={(e) => setInput(e.target.value)} value={input} type="text" placeholder="Search..." />
            {isLoading ? <Skeleton height={150} count={4} /> : <div>
                {data?.map((item) =>
                    <Card key={item.id} {...item} />
                )}
            </div>}
        </div>
    )
}
