import React from "react"
import { Link, Route, Routes } from "react-router-dom"
import { Search } from "./page/search"
import { Pagination } from "./page/pagination"

function App() {

  return (
    <div className="container my-3">
      <div className="flex items-center gap-4 p-3">
        <Link to="/pagination">Pagination</Link>
        <Link to="/">Search</Link>
      </div>
      <Routes>
        <Route path="/" element={<Search />} />
        <Route path="/pagination" element={<Pagination/>}/>
      </Routes>
    </div>
  )
}

export default App
