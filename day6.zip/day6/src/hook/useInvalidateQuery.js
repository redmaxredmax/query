import { client } from '../main'

export const useInvalidateQuery = () => {

    const Invalidate = (key) => {
        client.invalidateQueries({ queryKey: [...key] })
    }
    return { Invalidate }
}
