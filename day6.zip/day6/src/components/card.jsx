import React from 'react'
import { Link } from 'react-router-dom'

export const Card = ({ title, description, id }) => {
    return (
        <div className='w-[800px]  text-center border-2 pb-2 p-2 mb-2 border-black'> 
            <div className='w-[700px] mx-auto p-3 border-b-2 border-black text-center'>
                <h1 className='text-3xl text-red-300 font-semibold'>{title}</h1>
                <p>{description}</p>
                <button className='bg-blue-400 w-full text-white text-base outline-none p-1 rounded-lg'>
                    Delete
                </button>
            </div>
        </div>
    )
}
